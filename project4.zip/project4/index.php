<?php

require 'vendor/autoload.php';
require 'boost.php';